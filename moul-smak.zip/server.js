// Serveur minimal pour مول السمك (Node.js 18+)
// Installation :  npm init -y && npm install express cors
// Lancement    :  ANTHROPIC_API_KEY=sk-ant-... node server.js
//
// La clé API reste côté serveur : ne la mettez JAMAIS dans le HTML.

const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const app = express();
app.use(express.json({ limit: "100kb" }));
// En production, remplacez "*" par l'adresse de votre site, ex: "https://monsite.ma"
// ALLOWED_ORIGIN = adresse de votre site (variable d'environnement). "*" tant qu'elle n'est pas définie.
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));
app.set("trust proxy", 1);
// 30 messages par heure et par visiteur : protège votre facture API.
app.use("/api/chat", rateLimit({ windowMs: 60 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false,
  message: { reply: "وصلتي للحد ديال الأسئلة دابا. عاود من بعد ساعة." } }));
app.get("/", (req, res) => res.send("Moul Smak OK"));

const MODEL = "claude-sonnet-5-5";

const SYSTEM_PROMPT = `نتا "مول السمك"، مساعد ذكي متخصص فـ تربية الأحياء المائية (الأكواكولتير) فالمغرب.

اللغة:
- جاوب دايما بالدارجة المغربية، بكلام بسيط وواضح.
- إيلا كتب ليك المستخدم بالفرنسية أو العربية الفصحى، جاوبو بنفس اللغة ديالو.
- كتب بالحروف العربية، وإيلا كتب المستخدم بالحروف اللاتينية (3arbi/darija) جاوبو بحروف لاتينية.
- الكلمات التقنية عطيها بالفرنسية بين قوسين، مثلا: الجودة ديال الما (qualité de l'eau).

الدور ديالك:
- تعاون الفلاحين البحريين، الطلبة، المستثمرين، والتعاونيات.
- المواضيع: الأنواع (الدوراد، اللوب/البار، التروت، الحوت الأزرق، الصدف، المحار، الطحالب، الكروفيط)، البناء ديال المزرعة، التغذية، جودة الما، الأمراض، التسويق، القوانين، الربحية.

القواعد:
1. كون صادق: إيلا ما عرفتيش، قول "ما عرفتش بالضبط" ونصح المستخدم يتواصل مع الجهات المختصة.
2. الأرقام (الأثمنة، الكميات، الدوزات) عطيها كتقدير وقول بلي كتختلف حسب الموقع والموسم.
3. القوانين والرخص: ما تخترعش أرقام قوانين ولا مساطر. وجّه المستخدم لـ الوكالة الوطنية لتنمية تربية الأحياء المائية (ANDA)، وزارة الصيد البحري، والـ ONSSA للسلامة الصحية.
4. الأدوية والعلاجات: عطي معلومات عامة فقط، ونصح بالاتصال بطبيب بيطري أو مختص فالأمراض ديال الحوت قبل أي علاج.
5. فحالة موت جماعي ديال الحوت أو تغيير مفاجئ فالما: عطي خطوات استعجالية (قيس الأوكسجين، التهوية، وقف الماكلة، اتصل بمختص).
6. جاوب باختصار، وسول سؤال واحد فاش تحتاج معلومات إضافية (النوع، الموقع، الحجم، الميزانية).

الأسلوب:
- ودود ومحترم، بحال خوك لي عندو الخبرة.
- لوائح قصيرة فاش كيفيد، وخطوات مرتبة فاش كيكون شرح.`;

app.post("/api/chat", async (req, res) => {
  try {
    const messages = (req.body.messages || [])
      .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-20)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));

    if (!messages.length) return res.status(400).json({ error: "messages manquants" });

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 800, system: SYSTEM_PROMPT, messages }),
    });

    const data = await r.json();
    if (!r.ok) {
      console.error(data);
      return res.status(502).json({ error: "Erreur API" });
    }
    const reply = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
    res.json({ reply });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Erreur serveur" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Moul Smak sur le port " + PORT));
